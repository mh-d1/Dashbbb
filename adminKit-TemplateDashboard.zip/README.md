# AdminKit

AdminKit is a polished, responsive admin dashboard starter built with HTML5, CSS3, and vanilla JavaScript. It is designed to be adapted to a REST backend without requiring a front-end framework.

> **Demo notice:** The included user records, profile, preferences, and notification state are browser-local demo data. They are not authentication, authorization, or secure storage. Front-end role labels only simulate the UI; enforce identity and permissions on your server.

## Features

- Ten standalone pages: login, dashboard, users, roles and permissions, activity, notifications, reports, settings, profile, and 404.
- Responsive sidebar navigation, mobile menu, reusable layout, light/dark theme persistence, and toast feedback.
- Dashboard statistics, Chart.js activity and role charts, member management, search, role/status filters, and pagination.
- Add, edit, and remove demo users with form validation and a confirmation dialog.
- Notification read state, profile and workspace forms, preference switches, and CSV downloads.
- Central Fetch API client with GET, POST, PUT, PATCH, DELETE, optional bearer token, explicit errors, and a request-loading event.

## Folder structure

```text
.
├── index.html
├── login.html
├── dashboard.html
├── users.html
├── roles.html
├── activity.html
├── notifications.html
├── reports.html
├── settings.html
├── profile.html
├── 404.html
├── css/
│   └── styles.css
├── js/
│   ├── app.js
│   └── api.js
├── assets/
│   ├── STARTER-KIT.md
│   ├── adminkit-cover.svg
│   └── adminkit-social-card.svg
└── documentation/
```

The `assets/` folder includes a short promotional starter guide plus two editable, scalable SVG illustrations for product listings and social previews. The artwork is a static mockup labeled as illustrative, not a live application screenshot.

## Run locally

Open `index.html` in a modern browser, or serve this folder using any static HTTP server. For example, from this folder:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000/`. Internet access is needed for the hosted Inter font, Lucide icons, and Chart.js CDN assets. The other pages can be opened directly or reached through the sidebar.

## Change the branding

- Replace the `AdminKit` brand text in `js/app.js` (the shared shell and login screen).
- Adjust the color tokens at the top of `css/styles.css` for the light and dark palettes.
- Update the sample organization, profile defaults, and demonstration content in `js/app.js`.
- Replace the title and theme-color metadata in the page HTML files to match your product.

## Connect a backend API

`js/api.js` exposes `window.AdminKitAPI` and can be loaded on pages that need backend data. Set configuration **before** loading it:

```html
<script>
  window.ADMINKIT_CONFIG = {
    API_BASE_URL: 'https://api.example.com/v1/',
    AUTH_TOKEN: ''
  };
</script>
<script src="js/api.js"></script>
```

The empty token is intentional. Integrate your authentication provider and supply short-lived credentials using your application's security architecture; do not put production secrets or long-lived tokens in source code or localStorage.

```js
const members = await window.AdminKitAPI.get('users');
await window.AdminKitAPI.post('users', { name: 'Alex Morgan' });
await window.AdminKitAPI.put('users/123', { name: 'Alex Morgan' });
await window.AdminKitAPI.patch('users/123', { status: 'active' });
await window.AdminKitAPI.delete('users/123');
```

Requests return parsed JSON (or `null` for an empty response) and reject with `AdminKitAPI.ApiError`, including `status` and response `data`. A `adminkit:loading` event is dispatched on `window` with `{ loading, activeRequests }` while requests are in progress. Replace the localStorage demo handlers in `js/app.js` with API calls and map your backend's response shapes before using production data.

## API endpoint configuration

- `API_BASE_URL` defaults to `/api/` and can be overridden with `window.ADMINKIT_CONFIG` before `js/api.js` loads.
- API paths are relative to that base URL; methods accept standard Fetch options as their final argument.
- `AUTH_TOKEN` defaults to an empty string. When configured, it is sent as `Authorization: Bearer <token>`; an individual request can override it with its `token` option.
- Non-success HTTP responses and network errors reject explicitly; no success-shaped fallback is returned.

See [documentation/API-INTEGRATION.md](documentation/API-INTEGRATION.md) for a focused integration checklist.

## Known limitations

- This is a front-end template, not a production-ready identity or access-management system.
- Demo CRUD, notification state, theme, and profile preferences use localStorage and are limited to the current browser.
- Login does not authenticate or create a secure session. Connect an identity provider or backend before deployment.
- Role cards are illustrative; front-end role values must never be treated as server-side authorization.
- Activity, analytics, and report values are sample data; connect API endpoints for real workspace metrics.
- Hosted font, icon, and chart libraries require network access.
