(() => {
  'use strict';

  const config = window.ADMINKIT_CONFIG || {};
  const API_BASE_URL = config.API_BASE_URL || '/api/';
  const AUTH_TOKEN = config.AUTH_TOKEN || '';
  let activeRequests = 0;

  class ApiError extends Error {
    constructor(message, status, data) {
      super(message);
      this.name = 'ApiError';
      this.status = status;
      this.data = data;
    }
  }

  function setLoading(active) {
    activeRequests = Math.max(0, activeRequests + (active ? 1 : -1));
    const loading = activeRequests > 0;
    document.documentElement.classList.toggle('api-loading', loading);
    window.dispatchEvent(new CustomEvent('adminkit:loading', { detail: { loading, activeRequests } }));
  }

  async function request(method, path, body, options = {}) {
    const url = new URL(String(path).replace(/^\/+/, ''), new URL(API_BASE_URL, window.location.href));
    const headers = new Headers(options.headers || {});
    headers.set('Accept', 'application/json');
    if (body !== undefined) headers.set('Content-Type', 'application/json');
    const token = options.token ?? AUTH_TOKEN;
    if (token) headers.set('Authorization', `Bearer ${token}`);

    const fetchOptions = { ...options, method, headers };
    delete fetchOptions.token;
    if (body !== undefined) fetchOptions.body = JSON.stringify(body);

    setLoading(true);
    try {
      const response = await fetch(url, fetchOptions);
      const responseText = response.status === 204 ? '' : await response.text();
      let data = null;
      if (responseText) {
        try {
          data = JSON.parse(responseText);
        } catch {
          data = responseText;
        }
      }
      if (!response.ok) {
        const message = data && typeof data === 'object' && data.message
          ? data.message
          : `Request failed with status ${response.status}.`;
        throw new ApiError(message, response.status, data);
      }
      return data;
    } catch (error) {
      if (error instanceof ApiError) throw error;
      console.error(`API ${method} ${url.pathname} failed.`, error);
      throw new ApiError(error.message || 'The API request could not be completed.', 0, null);
    } finally {
      setLoading(false);
    }
  }

  window.AdminKitAPI = Object.freeze({
    API_BASE_URL,
    ApiError,
    get: (path, options) => request('GET', path, undefined, options),
    post: (path, body, options) => request('POST', path, body, options),
    put: (path, body, options) => request('PUT', path, body, options),
    patch: (path, body, options) => request('PATCH', path, body, options),
    delete: (path, options) => request('DELETE', path, undefined, options)
  });
})();
