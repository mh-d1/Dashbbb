(() => {
  'use strict';

  const PAGE_INFO = {
    dashboard: ['Dashboard', 'A clear overview of your workspace and activity.'],
    users: ['User management', 'Manage team members, access, and account status.'],
    roles: ['Roles & permissions', 'Review the access levels available in your workspace.'],
    activity: ['Activity logs', 'A transparent record of recent workspace changes.'],
    notifications: ['Notifications', 'Stay up to date with important workspace events.'],
    reports: ['Reports', 'Explore your workspace metrics and export reports.'],
    settings: ['Settings', 'Configure workspace preferences and notifications.'],
    profile: ['My profile', 'Manage your personal information and preferences.'],
    'not-found': ['Page not found', 'The page you are looking for is unavailable.']
  };
  const NAV_ITEMS = [
    { page: 'dashboard', label: 'Dashboard', icon: 'layout-dashboard', href: 'dashboard.html', section: 'Workspace' },
    { page: 'users', label: 'Users', icon: 'users', href: 'users.html' },
    { page: 'roles', label: 'Roles & permissions', icon: 'shield-check', href: 'roles.html' },
    { page: 'activity', label: 'Activity logs', icon: 'history', href: 'activity.html' },
    { page: 'notifications', label: 'Notifications', icon: 'bell', href: 'notifications.html', count: '3' },
    { page: 'reports', label: 'Reports', icon: 'chart-no-axes-column-increasing', href: 'reports.html', section: 'Insights' },
    { page: 'settings', label: 'Settings', icon: 'settings', href: 'settings.html', section: 'Workspace' }
  ];
  const USER_KEY = 'adminkit-demo-users';
  const PROFILE_KEY = 'adminkit-demo-profile';
  const THEME_KEY = 'adminkit-theme';
  const NOTIFICATION_KEY = 'adminkit-demo-notifications';
  const SEED_USERS = [
    { id: 'u-1001', name: 'Olivia Rhye', email: 'olivia.rhye@example.com', role: 'admin', status: 'active', joined: '2025-08-14' },
    { id: 'u-1002', name: 'Phoenix Baker', email: 'phoenix.baker@example.com', role: 'manager', status: 'active', joined: '2025-09-02' },
    { id: 'u-1003', name: 'Lana Steiner', email: 'lana.steiner@example.com', role: 'user', status: 'active', joined: '2025-09-18' },
    { id: 'u-1004', name: 'Demi Wilkinson', email: 'demi.wilkinson@example.com', role: 'manager', status: 'pending', joined: '2025-10-03' },
    { id: 'u-1005', name: 'Candice Wu', email: 'candice.wu@example.com', role: 'user', status: 'active', joined: '2025-10-21' },
    { id: 'u-1006', name: 'Natali Craig', email: 'natali.craig@example.com', role: 'user', status: 'inactive', joined: '2025-11-06' },
    { id: 'u-1007', name: 'Drew Cano', email: 'drew.cano@example.com', role: 'user', status: 'active', joined: '2025-11-19' },
    { id: 'u-1008', name: 'Orlando Diggs', email: 'orlando.diggs@example.com', role: 'manager', status: 'active', joined: '2025-12-11' },
    { id: 'u-1009', name: 'Andi Lane', email: 'andi.lane@example.com', role: 'user', status: 'pending', joined: '2026-01-08' },
    { id: 'u-1010', name: 'Kate Morrison', email: 'kate.morrison@example.com', role: 'user', status: 'active', joined: '2026-01-26' },
    { id: 'u-1011', name: 'John Smith', email: 'john.smith@example.com', role: 'manager', status: 'active', joined: '2026-02-04' },
    { id: 'u-1012', name: 'Sarah Chen', email: 'sarah.chen@example.com', role: 'user', status: 'active', joined: '2026-02-17' }
  ];
  const SEED_NOTIFICATIONS = [
    { id: 'n1', title: 'New team member joined', message: 'Sarah Chen accepted her invitation and joined the workspace.', time: '10 minutes ago', icon: 'user-plus', unread: true },
    { id: 'n2', title: 'Weekly report is ready', message: 'Your workspace summary for this week is ready to review.', time: '2 hours ago', icon: 'chart-no-axes-column-increasing', unread: true },
    { id: 'n3', title: 'Security settings updated', message: 'Two-factor authentication requirements were updated by Olivia Rhye.', time: 'Yesterday', icon: 'shield-check', unread: true },
    { id: 'n4', title: 'Invitation pending', message: 'Demi Wilkinson has not accepted the workspace invitation yet.', time: '2 days ago', icon: 'mail', unread: false }
  ];
  const ROLE_INFO = [
    { role: 'admin', title: 'Administrator', description: 'Full access to workspace settings, team management, and reports.', icon: 'shield-check', permissions: ['All permissions', 'Manage workspace', 'Invite members'] },
    { role: 'manager', title: 'Manager', description: 'Can manage team members and view workspace reports.', icon: 'briefcase-business', permissions: ['Manage members', 'View reports', 'Review activity'] },
    { role: 'user', title: 'User', description: 'Standard workspace access for day-to-day collaboration.', icon: 'user-round', permissions: ['View workspace', 'Edit own profile', 'Read updates'] }
  ];
  let users = loadStored(USER_KEY, SEED_USERS);
  let notifications = loadStored(NOTIFICATION_KEY, SEED_NOTIFICATIONS);
  let profile = loadStored(PROFILE_KEY, { name: 'Olivia Rhye', email: 'olivia.rhye@example.com', role: 'Administrator', department: 'Product & Design', location: 'San Francisco, CA', bio: 'Building thoughtful digital experiences.' });
  let currentPage = 1;
  const pageSize = 6;

  function loadStored(key, fallback) {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : structuredCopy(fallback);
    } catch (error) {
      console.error(`Unable to load ${key} from localStorage.`, error);
      return structuredCopy(fallback);
    }
  }

  function structuredCopy(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function saveStored(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error(`Unable to save ${key} to localStorage.`, error);
      showToast('Could not save your changes in this browser.', 'error');
      return false;
    }
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[character]);
  }

  function initials(name) {
    return String(name).trim().split(/\s+/).slice(0, 2).map(part => part.charAt(0)).join('').toUpperCase();
  }

  function icon(name, className = '') {
    return `<i data-lucide="${escapeHtml(name)}"${className ? ` class="${escapeHtml(className)}"` : ''} aria-hidden="true"></i>`;
  }

  function refreshIcons() {
    if (window.lucide) window.lucide.createIcons();
  }

  function showToast(message, type = 'success') {
    const region = document.getElementById('toast-region');
    if (!region) return;
    const toast = document.createElement('div');
    toast.className = `toast${type === 'error' ? ' error' : ''}`;
    toast.innerHTML = `${icon(type === 'error' ? 'circle-alert' : 'circle-check')}<span>${escapeHtml(message)}</span>`;
    region.append(toast);
    refreshIcons();
    window.setTimeout(() => toast.remove(), 3500);
  }

  function avatar(name, small = false) {
    return `<span class="avatar${small ? ' small' : ''}" aria-hidden="true">${escapeHtml(initials(name))}</span>`;
  }

  function renderShell(page, content) {
    const nav = NAV_ITEMS.map((item, index) => {
      const sectionLabel = item.section && (index === 0 || item.section !== NAV_ITEMS[index - 1].section)
        ? `<div class="nav-caption">${escapeHtml(item.section)}</div>` : '';
      const unreadCount = item.page === 'notifications' ? notifications.filter(notification => notification.unread).length : 0;
      return `${sectionLabel}<a class="nav-link${page === item.page ? ' active' : ''}" href="${item.href}"${page === item.page ? ' aria-current="page"' : ''}>${icon(item.icon)}<span>${escapeHtml(item.label)}</span>${item.page === 'notifications' && unreadCount ? `<span class="nav-count">${unreadCount}</span>` : ''}</a>`;
    }).join('');
    const [title] = PAGE_INFO[page] || PAGE_INFO.dashboard;
    return `<div class="app-shell">
      <aside class="sidebar" aria-label="Main navigation">
        <a class="brand" href="dashboard.html"><span class="brand-mark">${icon('layers-3')}</span><span>AdminKit</span></a>
        <nav class="nav-list">${nav}</nav>
        <div class="sidebar-bottom">
          <div class="sidebar-help"><strong>Need a hand?</strong><p>Visit our documentation for setup guides and API integration tips.</p><a href="README.md">Open documentation ${icon('arrow-up-right')}</a></div>
          <div class="sidebar-user">${avatar(profile.name, true)}<div class="user-meta"><strong>${escapeHtml(profile.name)}</strong><small>${escapeHtml(profile.email)}</small></div></div>
        </div>
      </aside>
      <main class="main-area">
        <header class="topbar">
          <div class="topbar-left"><button class="icon-button menu-toggle" type="button" data-action="toggle-nav" aria-label="Toggle navigation">${icon('menu')}</button><div class="breadcrumb"><span>Workspace</span>${icon('chevron-right')}<strong>${escapeHtml(title)}</strong></div></div>
          <div class="topbar-actions">
            <button class="icon-button" type="button" data-action="theme" aria-label="Toggle light and dark theme" title="Toggle theme">${icon(document.body.classList.contains('theme-dark') ? 'sun' : 'moon')}</button>
            <a class="icon-button" href="notifications.html" aria-label="Notifications" title="Notifications">${icon('bell')}${notifications.some(notification => notification.unread) ? '<span class="notification-dot"></span>' : ''}</a>
            <a class="top-action" href="profile.html">${avatar(profile.name, true)}<span><strong>${escapeHtml(profile.name)}</strong><small>Administrator</small></span>${icon('chevron-down')}</a>
          </div>
        </header>
        <div class="page-content">${content}</div>
      </main>
    </div>`;
  }

  function heading(title, description, actions = '') {
    return `<div class="page-heading"><div><h1>${escapeHtml(title)}</h1><p>${escapeHtml(description)}</p></div>${actions ? `<div class="heading-actions">${actions}</div>` : ''}</div>`;
  }

  function button(label, action, iconName, extra = '') {
    return `<button type="button" class="btn${extra ? ` ${extra}` : ''}" data-action="${escapeHtml(action)}">${iconName ? icon(iconName) : ''}${escapeHtml(label)}</button>`;
  }

  function renderDashboard() {
    const activeCount = users.filter(user => user.status === 'active').length;
    const managerCount = users.filter(user => user.role === 'manager').length;
    return `${heading('Good morning, Olivia', 'Here is what is happening across your workspace today.', button('Export report', 'export-report', 'download') + button('Add user', 'add-user', 'user-plus', 'btn-primary'))}
      <section class="stats-grid" aria-label="Workspace statistics">
        ${statCard('Total members', users.length.toLocaleString(), '+12.5%', 'users', 'vs. last month', 'up')}
        ${statCard('Active members', activeCount.toLocaleString(), '+8.2%', 'user-check', 'vs. last month', 'up')}
        ${statCard('Pending invites', users.filter(user => user.status === 'pending').length.toLocaleString(), '2 new', 'mail', 'awaiting response', 'up')}
        ${statCard('Managers', managerCount.toLocaleString(), '+2', 'shield-check', 'this quarter', 'up')}
      </section>
      <section class="dashboard-grid">
        <article class="card"><div class="card-head"><div><h2>Workspace activity</h2><p>Member activity across the selected period</p></div><select class="filter-select" aria-label="Activity period"><option>Last 7 months</option><option>Last 30 days</option></select></div><div class="card-body"><div class="chart-wrap"><canvas id="activity-chart" aria-label="Workspace activity chart"></canvas></div></div></article>
        <article class="card"><div class="card-head"><div><h2>Members by role</h2><p>Distribution across your team</p></div>${icon('ellipsis')}</div><div class="card-body"><div class="chart-wrap short"><canvas id="role-chart" aria-label="Members by role chart"></canvas></div><div class="legend-list">${[['Admin', users.filter(user => user.role === 'admin').length, '#4568e8'], ['Manager', managerCount, '#8a74e8'], ['User', users.filter(user => user.role === 'user').length, '#45b99a']].map(([label, count, color]) => `<div class="legend-row"><span class="legend-label"><i class="legend-dot" style="background:${color}"></i>${label}</span><span class="legend-value">${count}</span></div>`).join('')}</div></div></article>
      </section>
      <section class="card table-card"><div class="card-head"><div><h2>Recently added members</h2><p>Your newest workspace members</p></div><a class="btn btn-sm" href="users.html">View all ${icon('arrow-right')}</a></div><div class="table-scroll"><table><thead><tr><th>Member</th><th>Role</th><th>Status</th><th>Date joined</th><th></th></tr></thead><tbody>${users.slice(-4).reverse().map(userRow).join('')}</tbody></table></div></section>`;
  }

  function statCard(label, value, trend, iconName, note, direction) {
    return `<article class="card stat-card"><div class="stat-top"><span>${escapeHtml(label)}</span><span class="stat-icon">${icon(iconName)}</span></div><div class="stat-number">${escapeHtml(value)}</div><div class="stat-foot"><span class="trend-${direction}">${icon('trending-up')} ${escapeHtml(trend)}</span><span>${escapeHtml(note)}</span></div></article>`;
  }

  function statusBadge(status) {
    const style = status === 'active' ? 'success' : status === 'pending' ? 'warning' : 'danger';
    return `<span class="badge ${style}">${escapeHtml(status)}</span>`;
  }

  function roleBadge(role) {
    return `<span class="badge${role === 'admin' ? ' warning' : ''}">${escapeHtml(role)}</span>`;
  }

  function userRow(user) {
    return `<tr><td><div class="person-cell">${avatar(user.name, true)}<span><strong>${escapeHtml(user.name)}</strong><small>${escapeHtml(user.email)}</small></span></div></td><td>${roleBadge(user.role)}</td><td>${statusBadge(user.status)}</td><td>${escapeHtml(new Date(`${user.joined}T00:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }))}</td><td><div class="row-actions"><button class="icon-button" type="button" data-action="edit-user" data-id="${escapeHtml(user.id)}" aria-label="Edit ${escapeHtml(user.name)}" title="Edit">${icon('pencil')}</button><button class="icon-button" type="button" data-action="delete-user" data-id="${escapeHtml(user.id)}" aria-label="Delete ${escapeHtml(user.name)}" title="Delete">${icon('trash-2')}</button></div></td></tr>`;
  }

  function renderUsers() {
    return `${heading('User management', 'Add, update, and organize people in your workspace.', button('Export CSV', 'export-users', 'download') + button('Add user', 'add-user', 'user-plus', 'btn-primary'))}
      <section class="card table-card">
        <div class="table-tools"><label class="search-box">${icon('search')}<input id="user-search" type="search" placeholder="Search name or email..." aria-label="Search users"></label><select class="filter-select" id="role-filter" aria-label="Filter by role"><option value="">All roles</option><option value="admin">Admin</option><option value="manager">Manager</option><option value="user">User</option></select><select class="filter-select" id="status-filter" aria-label="Filter by status"><option value="">All statuses</option><option value="active">Active</option><option value="pending">Pending</option><option value="inactive">Inactive</option></select></div>
        <div id="user-table-region"></div>
      </section>`;
  }

  function renderUserTable(search = '', role = '', status = '') {
    const region = document.getElementById('user-table-region');
    if (!region) return;
    const normalized = search.trim().toLowerCase();
    const filtered = users.filter(user =>
      (!normalized || `${user.name} ${user.email}`.toLowerCase().includes(normalized)) &&
      (!role || user.role === role) && (!status || user.status === status)
    );
    const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
    currentPage = Math.min(currentPage, totalPages);
    const start = (currentPage - 1) * pageSize;
    const rows = filtered.slice(start, start + pageSize);
    region.innerHTML = `${rows.length ? `<div class="table-scroll"><table><thead><tr><th>Member</th><th>Role</th><th>Status</th><th>Date joined</th><th style="text-align:right">Actions</th></tr></thead><tbody>${rows.map(userRow).join('')}</tbody></table></div>` : '<div class="empty-state"><strong>No members found</strong>Try changing your search or filters.</div>'}
      <div class="table-footer"><span>Showing ${filtered.length ? start + 1 : 0}–${Math.min(start + pageSize, filtered.length)} of ${filtered.length} members</span><div class="pagination"><button type="button" data-action="page-prev" aria-label="Previous page" ${currentPage === 1 ? 'disabled' : ''}>${icon('chevron-left')}</button>${Array.from({ length: totalPages }, (_, index) => `<button type="button" class="${index + 1 === currentPage ? 'active' : ''}" data-action="page" data-page-number="${index + 1}" aria-label="Page ${index + 1}">${index + 1}</button>`).join('')}<button type="button" data-action="page-next" aria-label="Next page" ${currentPage === totalPages ? 'disabled' : ''}>${icon('chevron-right')}</button></div></div>`;
    refreshIcons();
  }

  function renderRoles() {
    return `${heading('Roles & permissions', 'Roles help your team access the right tools for their work.', button('Manage members', 'go-users', 'users', 'btn-primary'))}
      <div class="role-grid">${ROLE_INFO.map(item => {
        const memberCount = users.filter(user => user.role === item.role).length;
        return `<article class="card role-card"><div class="role-card-top"><div><h2>${escapeHtml(item.title)}</h2><p>${escapeHtml(item.description)}</p></div><span class="role-icon">${icon(item.icon)}</span></div><div class="role-permissions">${item.permissions.map(permission => `<span>${escapeHtml(permission)}</span>`).join('')}</div><div class="role-card-footer"><span>${memberCount} ${memberCount === 1 ? 'member' : 'members'}</span><button class="btn btn-sm" type="button" data-action="role-members" data-role="${item.role}">View members ${icon('arrow-right')}</button></div></article>`;
      }).join('')}</div>
      <div class="card" style="margin-top:17px"><div class="card-head"><div><h2>About role access</h2><p>Front-end role labels are for demonstration only.</p></div>${icon('info')}</div><div class="card-body" style="color:var(--muted);font-size:11px;line-height:1.7">Enforce all permissions on your server. Updating a role in this demo changes only the displayed member record; it does not grant secure access to backend resources.</div></div>`;
  }

  const ACTIVITY_EVENTS = [
    ['user-plus', 'Olivia Rhye', 'invited Sarah Chen to the workspace', 'Today, 9:42 AM'],
    ['pencil', 'Phoenix Baker', 'updated the team profile', 'Today, 9:15 AM'],
    ['shield-check', 'Olivia Rhye', 'changed the security settings', 'Today, 8:31 AM'],
    ['user-round-check', 'Sarah Chen', 'accepted a workspace invitation', 'Today, 8:05 AM'],
    ['download', 'Lana Steiner', 'exported the monthly member report', 'Yesterday, 4:18 PM'],
    ['user-minus', 'Olivia Rhye', 'removed an expired invitation', 'Yesterday, 2:27 PM'],
    ['settings-2', 'Phoenix Baker', 'updated notification preferences', 'Yesterday, 11:52 AM'],
    ['key-round', 'Olivia Rhye', 'updated the manager role permissions', 'Nov 6, 10:14 AM']
  ];

  function activityList(events = ACTIVITY_EVENTS) {
    return `<div class="activity-list">${events.map(([eventIcon, name, message, time]) => `<div class="activity-item"><span class="activity-icon">${icon(eventIcon)}</span><div class="activity-copy"><strong>${escapeHtml(name)}</strong> ${escapeHtml(message)}<small>${escapeHtml(time)}</small></div></div>`).join('')}</div>`;
  }

  function renderActivity() {
    return `${heading('Activity logs', 'Review the latest changes and actions in your workspace.', button('Export CSV', 'export-activity', 'download'))}
      <div class="activity-layout"><section class="card"><div class="card-head"><div><h2>Recent activity</h2><p>Latest workspace events</p></div><select class="filter-select" id="activity-filter" aria-label="Filter activity"><option value="all">All activity</option><option value="members">Member changes</option><option value="settings">Settings</option></select></div><div class="card-body" id="activity-list-region">${activityList()}</div></section>
      <aside class="card"><div class="card-head"><div><h2>Activity summary</h2><p>This month</p></div></div><div class="card-body">${[['Member changes', '24'], ['Profile updates', '18'], ['Reports exported', '7'], ['Settings changed', '4']].map(([label, value]) => `<div class="legend-row" style="padding:12px 0;border-bottom:1px solid var(--line)"><span class="legend-label">${label}</span><strong>${value}</strong></div>`).join('')}</div></aside></div>`;
  }

  function renderNotifications() {
    return `${heading('Notifications', 'Updates and reminders from your workspace.', button('Mark all as read', 'mark-all-read', 'check-check'))}
      <section class="card"><div id="notification-list">${notifications.map(notification => `<article class="notification-item${notification.unread ? ' unread' : ''}"><span class="activity-icon">${icon(notification.icon)}</span><div class="notification-copy"><strong>${escapeHtml(notification.title)}${notification.unread ? '<i class="unread-dot" aria-label="Unread"></i>' : ''}</strong><p>${escapeHtml(notification.message)}</p><time>${escapeHtml(notification.time)}</time></div>${notification.unread ? `<button class="btn btn-sm" type="button" data-action="mark-read" data-id="${escapeHtml(notification.id)}">Mark read</button>` : ''}</article>`).join('') || '<div class="empty-state"><strong>You are all caught up</strong>New updates will appear here.</div>'}</div></section>`;
  }

  function renderReports() {
    return `${heading('Reports', 'Track team growth and engagement over time.', button('Export CSV', 'export-report', 'download'))}
      <section class="stats-grid">${statCard('Members added', '38', '+14.2%', 'user-plus', 'compared to last period', 'up')}${statCard('Workspace visits', '2,841', '+6.8%', 'activity', 'compared to last period', 'up')}${statCard('Invites accepted', '92%', '+3.1%', 'mail-check', 'compared to last period', 'up')}${statCard('Avg. response time', '2.4h', '−0.5h', 'clock-3', 'compared to last period', 'up')}</section>
      <section class="dashboard-grid"><article class="card"><div class="card-head"><div><h2>Member growth</h2><p>New members over the selected period</p></div><select class="filter-select" aria-label="Report period"><option>Last 12 months</option><option>Last 30 days</option></select></div><div class="card-body"><div class="chart-wrap"><canvas id="report-growth-chart" aria-label="Member growth report"></canvas></div></div></article>
      <article class="card"><div class="card-head"><div><h2>Team composition</h2><p>Members by role</p></div></div><div class="card-body"><div class="chart-wrap short"><canvas id="report-role-chart" aria-label="Team composition report"></canvas></div><div class="legend-list">${ROLE_INFO.map(item => `<div class="legend-row"><span class="legend-label">${escapeHtml(item.title)}</span><span class="legend-value">${users.filter(user => user.role === item.role).length}</span></div>`).join('')}</div></div></article></section>
      <section class="card"><div class="card-head"><div><h2>Report details</h2><p>Workspace metrics included in this report</p></div><span class="badge success">Updated today</span></div><div class="card-body" style="font-size:11px;color:var(--muted);line-height:1.8">Reports use sample dashboard data. Connect the API in <code>js/api.js</code> to use your own backend metrics.</div></section>`;
  }

  function renderSettings() {
    return `${heading('Settings', 'Personalize your AdminKit workspace.', button('Save preferences', 'save-settings', 'save', 'btn-primary'))}
      <div class="settings-layout"><div><section class="card form-section"><h2>Workspace details</h2><p>Basic information that helps your team identify this workspace.</p><form id="workspace-form" novalidate><div class="field-grid"><div class="field"><label for="workspace-name">Workspace name</label><input id="workspace-name" name="workspaceName" value="Acme Studio" required minlength="2"><span class="form-error"></span></div><div class="field"><label for="workspace-url">Workspace URL</label><input id="workspace-url" name="workspaceUrl" value="acme-studio" required pattern="[a-z0-9]+(-[a-z0-9]+)*"><span class="form-error"></span></div><div class="field full"><label for="workspace-description">Description</label><textarea id="workspace-description" name="description">A collaborative space for our product and design teams.</textarea><span class="form-error"></span></div></div><div class="form-actions"><button class="btn btn-primary" type="submit">Save changes</button></div></form></section>
      <section class="card form-section"><h2>Appearance</h2><p>Choose the display settings that work best for you.</p><div class="switch-row"><div class="switch-copy"><strong>Dark theme</strong><small>Use a darker interface across AdminKit.</small></div><label class="switch"><input id="theme-switch" type="checkbox" aria-label="Enable dark theme"><span></span></label></div></section></div>
      <aside class="card form-section"><h2>Notifications</h2><p>Choose which workspace updates you would like to receive.</p>${[['email-updates', 'Email updates', 'Receive a weekly summary by email.'], ['member-activity', 'Member activity', 'Get updates when teammates join or make changes.'], ['security-alerts', 'Security alerts', 'Be notified about important security events.']].map(([id, title, description], index) => `<div class="switch-row"><div class="switch-copy"><strong>${title}</strong><small>${description}</small></div><label class="switch"><input class="preference-switch" id="${id}" type="checkbox" ${index !== 1 ? 'checked' : ''}><span></span></label></div>`).join('')}<div class="form-actions"><button class="btn btn-primary" type="button" data-action="save-settings">Save preferences</button></div></aside></div>`;
  }

  function renderProfile() {
    return `${heading('My profile', 'Your profile information is visible to members of this workspace.')}
      <div class="settings-layout"><div><section class="card profile-hero">${avatar(profile.name)}<div><h2>${escapeHtml(profile.name)}</h2><p>${escapeHtml(profile.email)}</p><span class="badge warning">${escapeHtml(profile.role)}</span></div></section>
      <section class="card form-section" style="margin-top:16px"><h2>Personal information</h2><p>Update your details and how others see you in the workspace.</p><form id="profile-form" novalidate><div class="field-grid"><div class="field"><label for="profile-name">Full name</label><input id="profile-name" name="name" value="${escapeHtml(profile.name)}" required minlength="2"><span class="form-error"></span></div><div class="field"><label for="profile-email">Email address</label><input id="profile-email" name="email" type="email" value="${escapeHtml(profile.email)}" required><span class="form-error"></span></div><div class="field"><label for="profile-department">Department</label><input id="profile-department" name="department" value="${escapeHtml(profile.department)}"></div><div class="field"><label for="profile-location">Location</label><input id="profile-location" name="location" value="${escapeHtml(profile.location)}"></div><div class="field full"><label for="profile-bio">About</label><textarea id="profile-bio" name="bio" maxlength="180">${escapeHtml(profile.bio)}</textarea><span class="form-error"></span></div></div><div class="form-actions"><button class="btn btn-primary" type="submit">Save profile</button></div></form></section></div>
      <aside class="card form-section"><h2>Account details</h2><p>Information about your workspace access.</p><div class="profile-details"><div class="detail-item"><small>Role</small><strong>${escapeHtml(profile.role)}</strong></div><div class="detail-item"><small>Member since</small><strong>Aug 14, 2025</strong></div><div class="detail-item"><small>Account status</small><strong>${statusBadge('active')}</strong></div><div class="detail-item"><small>Workspace</small><strong>Acme Studio</strong></div></div><a class="btn" href="settings.html" style="width:100%">Open settings ${icon('arrow-right')}</a></aside></div>`;
  }

  function render404() {
    return `<section class="not-found"><div class="error-code">404</div><h1>We could not find that page</h1><p>The link may be out of date or the page may have moved. Head back to your dashboard to continue.</p><a class="btn btn-primary" href="dashboard.html">${icon('arrow-left')} Back to dashboard</a></section>`;
  }

  function renderLogin() {
    return `<main class="login-page"><section class="login-aside"><a class="brand" href="dashboard.html"><span class="brand-mark">${icon('layers-3')}</span><span>AdminKit</span></a><div class="login-pitch"><h1>Make work feel a little more organized.</h1><p>A thoughtfully designed admin workspace for your team, users, and day-to-day operations.</p></div><footer>© 2026 AdminKit. Admin dashboard template.</footer></section><section class="login-form-wrap"><form class="login-form" id="login-form" novalidate><h2>Welcome back</h2><p>Sign in to your workspace to continue.</p><div class="field"><label for="login-email">Email address</label><input id="login-email" name="email" type="email" placeholder="you@company.com" autocomplete="email" required><span class="form-error"></span></div><div class="field"><label for="login-password">Password</label><input id="login-password" name="password" type="password" placeholder="Enter your password" autocomplete="current-password" required minlength="8"><span class="form-error"></span></div><button class="btn btn-primary" type="submit">Continue ${icon('arrow-right')}</button><div class="login-note">Demo template: this form does not authenticate users. Connect your identity provider or backend API before production use.</div></form></section></main>`;
  }

  function render() {
    let theme = 'light';
    try {
      theme = localStorage.getItem(THEME_KEY) || 'light';
    } catch (error) {
      console.error('Unable to read the saved theme.', error);
    }
    document.body.classList.toggle('theme-dark', theme === 'dark');
    const page = document.documentElement.dataset.page || 'dashboard';
    document.title = page === 'login' ? 'Sign in | AdminKit' : `${(PAGE_INFO[page] || PAGE_INFO.dashboard)[0]} | AdminKit`;
    if (page === 'login') document.getElementById('app').innerHTML = renderLogin();
    else {
      const content = ({
        dashboard: renderDashboard, users: renderUsers, roles: renderRoles, activity: renderActivity,
        notifications: renderNotifications, reports: renderReports, settings: renderSettings,
        profile: renderProfile, 'not-found': render404
      }[page] || render404)();
      document.getElementById('app').innerHTML = renderShell(page, content);
      if (page === 'users') renderUserTable();
      if (page === 'settings') {
        const themeSwitch = document.getElementById('theme-switch');
        if (themeSwitch) themeSwitch.checked = document.body.classList.contains('theme-dark');
        loadPreferences();
      }
      if (page === 'dashboard' || page === 'reports') renderCharts(page);
    }
    refreshIcons();
  }

  function renderCharts(page) {
    if (!window.Chart) return;
    const dark = document.body.classList.contains('theme-dark');
    const tickColor = dark ? '#9aa6ba' : '#8791a3';
    const gridColor = dark ? '#29364b' : '#edf0f5';
    const baseOptions = {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { backgroundColor: dark ? '#0a111f' : '#192338', padding: 10, titleFont: { family: 'Inter' }, bodyFont: { family: 'Inter' } } },
      scales: { x: { grid: { display: false }, border: { display: false }, ticks: { color: tickColor, font: { family: 'Inter', size: 10 } } }, y: { beginAtZero: true, grid: { color: gridColor }, border: { display: false, dash: [4, 4] }, ticks: { color: tickColor, font: { family: 'Inter', size: 10 }, precision: 0 } } }
    };
    const lineCanvas = document.getElementById(page === 'dashboard' ? 'activity-chart' : 'report-growth-chart');
    const period = document.querySelector(`[aria-label="${page === 'dashboard' ? 'Activity period' : 'Report period'}"]`)?.value || '';
    const shortPeriod = period === 'Last 30 days';
    if (lineCanvas) {
      Chart.getChart(lineCanvas)?.destroy();
      new Chart(lineCanvas, {
      type: 'line',
      data: {
        labels: shortPeriod ? ['Week 1', 'Week 2', 'Week 3', 'Week 4'] : page === 'dashboard' ? ['Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{ label: 'New members', data: shortPeriod ? [8, 12, 9, users.length] : page === 'dashboard' ? [18, 24, 21, 33, 28, 42, users.length] : [12, 19, 17, 26, 22, 32, 29, 38, 35, 44, 49, users.length + 36], borderColor: '#5372ed', backgroundColor: 'rgba(83,114,237,.11)', fill: true, tension: .38, borderWidth: 2, pointRadius: 3, pointBackgroundColor: '#fff', pointBorderWidth: 2 }]
      },
      options: { ...baseOptions, interaction: { intersect: false, mode: 'index' } }
      });
    }
    const doughnutCanvas = document.getElementById(page === 'dashboard' ? 'role-chart' : 'report-role-chart');
    if (doughnutCanvas) {
      Chart.getChart(doughnutCanvas)?.destroy();
      new Chart(doughnutCanvas, {
      type: 'doughnut',
      data: { labels: ['Admin', 'Manager', 'User'], datasets: [{ data: ['admin', 'manager', 'user'].map(role => Math.max(0, users.filter(user => user.role === role).length)), backgroundColor: ['#4568e8', '#8a74e8', '#45b99a'], borderWidth: 0, hoverOffset: 4 }] },
      options: { responsive: true, maintainAspectRatio: false, cutout: '72%', plugins: { legend: { display: false }, tooltip: { backgroundColor: dark ? '#0a111f' : '#192338', padding: 10 } } }
      });
    }
  }

  function openUserModal(user = null) {
    const editing = Boolean(user);
    document.body.insertAdjacentHTML('beforeend', `<div class="modal-backdrop" id="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-header"><h2 id="modal-title">${editing ? 'Edit member' : 'Add a team member'}</h2><button class="icon-button" type="button" data-action="close-modal" aria-label="Close dialog">${icon('x')}</button></div><form id="user-form" novalidate><div class="modal-body"><input type="hidden" name="userId" value="${escapeHtml(user?.id || '')}"><div class="field"><label for="member-name">Full name</label><input id="member-name" name="name" value="${escapeHtml(user?.name || '')}" required minlength="2" placeholder="e.g. Alex Morgan"><span class="form-error"></span></div><div class="field"><label for="member-email">Email address</label><input id="member-email" name="email" type="email" value="${escapeHtml(user?.email || '')}" required placeholder="alex@company.com"><span class="form-error"></span></div><div class="field"><label for="member-role">Role</label><select id="member-role" name="role" required><option value="user"${user?.role === 'user' ? ' selected' : ''}>User</option><option value="manager"${user?.role === 'manager' ? ' selected' : ''}>Manager</option><option value="admin"${user?.role === 'admin' ? ' selected' : ''}>Admin</option></select><span class="form-error"></span></div><div class="field"><label for="member-status">Status</label><select id="member-status" name="status"><option value="active"${user?.status === 'active' || !user ? ' selected' : ''}>Active</option><option value="pending"${user?.status === 'pending' ? ' selected' : ''}>Pending</option><option value="inactive"${user?.status === 'inactive' ? ' selected' : ''}>Inactive</option></select><span class="form-error"></span></div></div><div class="modal-footer"><button class="btn" type="button" data-action="close-modal">Cancel</button><button class="btn btn-primary" type="submit">${editing ? 'Save changes' : 'Add member'}</button></div></form></section></div>`);
    refreshIcons();
    document.getElementById('member-name')?.focus();
  }

  function showConfirm(message, id) {
    document.body.insertAdjacentHTML('beforeend', `<div class="modal-backdrop" id="modal-backdrop"><section class="modal" role="alertdialog" aria-modal="true" aria-labelledby="confirm-title"><div class="modal-header"><h2 id="confirm-title">Remove team member?</h2><button class="icon-button" type="button" data-action="close-modal" aria-label="Close dialog">${icon('x')}</button></div><div class="modal-body"><p style="margin:0;color:var(--muted);font-size:11px;line-height:1.7">${escapeHtml(message)} This action cannot be undone.</p></div><div class="modal-footer"><button class="btn" type="button" data-action="close-modal">Cancel</button><button class="btn btn-danger" type="button" data-action="confirm-delete" data-id="${escapeHtml(id)}">Remove member</button></div></section></div>`);
    refreshIcons();
  }

  function closeModal() {
    document.getElementById('modal-backdrop')?.remove();
  }

  function validateForm(form) {
    let valid = true;
    form.querySelectorAll('input, select, textarea').forEach(field => {
      if (field.type === 'hidden') return;
      const error = field.parentElement.querySelector('.form-error');
      if (error) error.textContent = '';
      if (!field.checkValidity()) {
        valid = false;
        field.setAttribute('aria-invalid', 'true');
        if (error) {
          error.textContent = field.validity.valueMissing ? 'This field is required.'
            : field.validity.typeMismatch ? 'Enter a valid email address.'
              : field.validity.tooShort ? `Please enter at least ${field.minLength} characters.`
                : field.validity.patternMismatch && field.id === 'workspace-url' ? 'Use lowercase letters, numbers, and single hyphens.'
                  : field.validity.patternMismatch ? 'Please use the required format.'
                    : 'Please check this field.';
        }
      } else {
        field.removeAttribute('aria-invalid');
      }
    });
    if (!valid) form.querySelector(':invalid')?.focus();
    return valid;
  }

  function exportCsv(filename, rows) {
    if (!rows.length) {
      showToast('There is no data to export.', 'error');
      return;
    }
    const csv = rows.map(row => row.map(value => `"${String(value ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
    const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.append(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    showToast('Your CSV export has started.');
  }

  function loadPreferences() {
    let preferences = {};
    try {
      preferences = JSON.parse(localStorage.getItem('adminkit-demo-preferences') || '{}');
    } catch (error) {
      console.error('Unable to load notification preferences.', error);
    }
    document.querySelectorAll('.preference-switch').forEach(input => {
      if (Object.prototype.hasOwnProperty.call(preferences, input.id)) input.checked = Boolean(preferences[input.id]);
    });
  }

  function saveSettings() {
    const form = document.getElementById('workspace-form');
    if (form && !validateForm(form)) {
      form.reportValidity();
      return;
    }
    const preferences = {};
    document.querySelectorAll('.preference-switch').forEach(input => { preferences[input.id] = input.checked; });
    if (!saveStored('adminkit-demo-preferences', preferences)) return;
    if (form && !saveStored('adminkit-demo-workspace', Object.fromEntries(new FormData(form).entries()))) return;
    showToast('Your preferences have been saved.');
  }

  function handleSubmit(event) {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (form.id === 'login-form') {
      event.preventDefault();
      if (!validateForm(form)) {
        form.reportValidity();
        return;
      }
      showToast('Demo sign-in only. Connect an authentication provider to continue.', 'error');
      return;
    }
    if (!['user-form', 'profile-form', 'workspace-form'].includes(form.id)) return;
    event.preventDefault();
    if (!validateForm(form)) {
      form.reportValidity();
      return;
    }
    const values = Object.fromEntries(new FormData(form).entries());
    if (form.id === 'user-form') {
      const duplicate = users.some(user => user.email.toLowerCase() === values.email.trim().toLowerCase() && user.id !== values.userId);
      if (duplicate) {
        const emailError = form.querySelector('#member-email').parentElement.querySelector('.form-error');
        emailError.textContent = 'A member with this email already exists.';
        form.querySelector('#member-email').focus();
        return;
      }
      if (values.userId) {
        const updatedUsers = users.map(user => user.id === values.userId ? { ...user, ...values, name: values.name.trim(), email: values.email.trim() } : user);
        if (!saveStored(USER_KEY, updatedUsers)) return;
        users = updatedUsers;
        showToast('Member details updated.');
      } else {
        const updatedUsers = [{ ...values, id: `u-${Date.now()}`, name: values.name.trim(), email: values.email.trim(), joined: new Date().toISOString().slice(0, 10) }, ...users];
        if (!saveStored(USER_KEY, updatedUsers)) return;
        users = updatedUsers;
        showToast('New member added.');
      }
      closeModal();
      render();
      return;
    }
    if (form.id === 'profile-form') {
      const updatedProfile = { ...profile, ...values };
      if (!saveStored(PROFILE_KEY, updatedProfile)) return;
      profile = updatedProfile;
      showToast('Your profile has been updated.');
      render();
      return;
    }
    if (saveStored('adminkit-demo-workspace', values)) showToast('Workspace details have been saved.');
  }

  document.addEventListener('submit', handleSubmit);

  document.addEventListener('input', event => {
    if (event.target.id === 'user-search') {
      currentPage = 1;
      renderUserTable(event.target.value, document.getElementById('role-filter')?.value || '', document.getElementById('status-filter')?.value || '');
      const search = document.getElementById('user-search');
      search?.focus();
      if (search) search.setSelectionRange(search.value.length, search.value.length);
    }
  });

  document.addEventListener('change', event => {
    if (['role-filter', 'status-filter'].includes(event.target.id)) {
      currentPage = 1;
      renderUserTable(document.getElementById('user-search')?.value || '', document.getElementById('role-filter')?.value || '', document.getElementById('status-filter')?.value || '');
    }
    if (event.target.id === 'theme-switch') toggleTheme(event.target.checked);
    if (event.target.matches('[aria-label="Activity period"], [aria-label="Report period"]')) {
      renderCharts(document.documentElement.dataset.page);
    }
    if (event.target.id === 'activity-filter') {
      const region = document.getElementById('activity-list-region');
      const events = event.target.value === 'members' ? ACTIVITY_EVENTS.filter(item => /user-|invited|invitation|member/i.test(`${item[0]} ${item[2]}`))
        : event.target.value === 'settings' ? ACTIVITY_EVENTS.filter(item => /settings|role permissions/i.test(item[2]))
          : ACTIVITY_EVENTS;
      if (region) region.innerHTML = activityList(events);
      refreshIcons();
    }
  });

  function toggleTheme(forceValue) {
    const enable = typeof forceValue === 'boolean' ? forceValue : !document.body.classList.contains('theme-dark');
    document.body.classList.toggle('theme-dark', enable);
    try {
      localStorage.setItem(THEME_KEY, enable ? 'dark' : 'light');
    } catch (error) {
      console.error('Unable to save the selected theme.', error);
      showToast('Theme changed for this session, but could not be saved.', 'error');
    }
    if (document.getElementById('theme-switch')) document.getElementById('theme-switch').checked = enable;
    const buttonIcon = document.querySelector('[data-action="theme"]');
    if (buttonIcon) {
      buttonIcon.innerHTML = icon(enable ? 'sun' : 'moon');
      refreshIcons();
    }
    const page = document.documentElement.dataset.page;
    if (page === 'dashboard' || page === 'reports') render();
  }

  document.addEventListener('click', event => {
    const actionElement = event.target.closest('[data-action]');
    if (document.body.classList.contains('nav-open') && !event.target.closest('.sidebar') && !event.target.closest('[data-action="toggle-nav"]')) document.body.classList.remove('nav-open');
    if (!actionElement) {
      if (event.target.id === 'modal-backdrop') closeModal();
      return;
    }
    const { action, id } = actionElement.dataset;
    if (action === 'toggle-nav') document.body.classList.toggle('nav-open');
    else if (action === 'theme') toggleTheme();
    else if (action === 'add-user') openUserModal();
    else if (action === 'edit-user') openUserModal(users.find(user => user.id === id));
    else if (action === 'delete-user') {
      const user = users.find(item => item.id === id);
      if (user) showConfirm(`Remove ${user.name} from this workspace?`, id);
    } else if (action === 'confirm-delete') {
      const updatedUsers = users.filter(user => user.id !== id);
      if (!saveStored(USER_KEY, updatedUsers)) return;
      users = updatedUsers;
      closeModal();
      render();
      showToast('Member removed from the workspace.');
    } else if (action === 'close-modal') closeModal();
    else if (action === 'page' || action === 'page-next' || action === 'page-prev') {
      const role = document.getElementById('role-filter')?.value || '';
      const status = document.getElementById('status-filter')?.value || '';
      const search = document.getElementById('user-search')?.value || '';
      const filtered = users.filter(user => (!search || `${user.name} ${user.email}`.toLowerCase().includes(search.toLowerCase())) && (!role || user.role === role) && (!status || user.status === status));
      const maxPage = Math.max(1, Math.ceil(filtered.length / pageSize));
      currentPage = action === 'page' ? Number(actionElement.dataset.pageNumber) : Math.max(1, Math.min(maxPage, currentPage + (action === 'page-next' ? 1 : -1)));
      renderUserTable(search, role, status);
    } else if (action === 'export-users') exportCsv('adminkit-users.csv', [['Name', 'Email', 'Role', 'Status', 'Date joined'], ...users.map(user => [user.name, user.email, user.role, user.status, user.joined])]);
    else if (action === 'export-activity') exportCsv('adminkit-activity.csv', [['Actor', 'Activity', 'Date'], ...ACTIVITY_EVENTS.map(item => [item[1], item[2], item[3]])]);
    else if (action === 'export-report') exportCsv('adminkit-report.csv', [['Metric', 'Value'], ['Total members', users.length], ['Active members', users.filter(user => user.status === 'active').length], ['Pending invitations', users.filter(user => user.status === 'pending').length], ['Administrators', users.filter(user => user.role === 'admin').length], ['Managers', users.filter(user => user.role === 'manager').length], ['Users', users.filter(user => user.role === 'user').length]]);
    else if (action === 'go-users') window.location.href = 'users.html';
    else if (action === 'role-members') window.location.href = `users.html?role=${encodeURIComponent(actionElement.dataset.role)}`;
    else if (action === 'mark-all-read') {
      const updatedNotifications = notifications.map(item => ({ ...item, unread: false }));
      if (!saveStored(NOTIFICATION_KEY, updatedNotifications)) return;
      notifications = updatedNotifications;
      render();
      showToast('All notifications marked as read.');
    } else if (action === 'mark-read') {
      const updatedNotifications = notifications.map(item => item.id === id ? { ...item, unread: false } : item);
      if (!saveStored(NOTIFICATION_KEY, updatedNotifications)) return;
      notifications = updatedNotifications;
      render();
    } else if (action === 'save-settings') saveSettings();
  });

  const initialPage = document.documentElement.dataset.page;
  render();
  if (initialPage === 'users') {
    const queryRole = new URLSearchParams(window.location.search).get('role');
    if (queryRole && ['admin', 'manager', 'user'].includes(queryRole)) {
      const roleFilter = document.getElementById('role-filter');
      if (roleFilter) roleFilter.value = queryRole;
      renderUserTable('', queryRole);
    }
  }
})();
