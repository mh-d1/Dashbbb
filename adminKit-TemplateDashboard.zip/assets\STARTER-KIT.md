# AdminKit promotion starter kit

Use these starter materials to introduce AdminKit on a product page, marketplace listing, or social post. Adapt the wording to the requirements of the platform where you publish it.

## Product summary

AdminKit is a responsive, multi-page admin dashboard template built with HTML, CSS, and vanilla JavaScript. It includes a coherent UI, browser-based demo interactions, and a separate Fetch client to help you start connecting your own REST API.

## Ready-to-use copy

**Headline**  
A Faster Start for Admin Dashboards

**Short description**  
Start with 10 coordinated admin pages, responsive layouts, and interactive browser demos. Customize the HTML, CSS, and vanilla JavaScript, then connect your own backend.

**Feature bullets**

- Ten pages, from dashboard and user management to settings and profile.
- Search, filters, pagination, and demo user CRUD.
- Light and dark themes with saved browser preference.
- Chart.js charts and CSV export for sample data.
- Fetch API client with common HTTP methods and configurable base URL.

**Call to action**  
Explore the pages. Make AdminKit your dashboard starting point.

## Free preview contents

- `adminkit-cover.svg` — scalable product cover for a listing or product page.
- `adminkit-social-card.svg` — landscape social or email preview card.
- This guide — starter copy, setup reminders, and an honest feature checklist.

The SVG artwork is a static promotional illustration, not a live screenshot of the dashboard. The demo UI uses sample data. The API client is provided as an integration starting point; the app's demo CRUD is not connected to a backend.

## Quick-start checklist

1. Preview `../dashboard.html` and the other standalone HTML pages in a browser.
2. Run a static server from the project root, such as `python -m http.server 8000`.
3. Change the product name, palette, and sample content to match your brand.
4. Configure `window.ADMINKIT_CONFIG` before loading `js/api.js`.
5. Replace demo handlers with API calls and map responses to your backend.
6. Test the result at mobile and desktop widths before publishing.

## Claims and usage notes

- Login is a UI demo and does not authenticate anyone.
- Roles are display-only and do not enforce permissions.
- User records, preferences, and notification state are browser-local demo data.
- Charts and activity/report metrics are sample data.
- Inter, Lucide, and Chart.js are loaded from external CDNs by the demo.
- Check the product's applicable license before redistributing source files or artwork.
