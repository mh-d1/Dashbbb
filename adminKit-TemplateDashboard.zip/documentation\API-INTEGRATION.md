# API integration checklist

1. Configure `window.ADMINKIT_CONFIG` before loading `js/api.js`; use your API's versioned base URL.
2. Connect login to your identity provider. Do not treat the demo form or localStorage as authentication.
3. Replace the demo collection and mutation handlers in `js/app.js` with calls to `window.AdminKitAPI`.
4. Map and validate server responses at the boundary. Keep permission checks and input validation on the server.
5. Handle rejected requests in the UI and show a useful error state; the client throws `AdminKitAPI.ApiError` for HTTP and network failures.
6. Observe `adminkit:loading` if the integration needs a shared loading indicator.
7. Test expired credentials, permission failures, empty results, pagination, and API/network outages.

The client supports GET, POST, PUT, PATCH, and DELETE. Its optional bearer token is a wiring placeholder, not a token-storage recommendation. Choose a production authentication flow appropriate to your backend and threat model.
